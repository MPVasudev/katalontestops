import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/**
 1. Open brower and navigate to GlobalVariable.FURL
 2. Enter the serach text with the local variable 'Keyword' at ID 'FlipKart/SearchResult_Flipkart.com/input_Trending_q' and submit
 3. Save value of the element text present with ID 'FlipKart/Home Page Flipkart.com/span_grocery' in a local variable 'Actual Result' after removing the double quotes from string
 4. Verify the element text with the local variable 'Actual Result' same as the local variable Result
 5. Close the browser
 **/
// Open browser and navigate to the specified URL
WebUI.openBrowser('')

// Navigate to the URL stored in GlobalVariable.FURL
WebUI.navigateToUrl(GlobalVariable.FURL)

// Enter the search text using the local variable 'Keyword' in the input field with the specified ID and submit the form
WebUI.setText(findTestObject('FlipKart/SearchResult_Flipkart.com/input_Trending_q'), Keyword)
WebUI.submit(findTestObject('FlipKart/SearchResult_Flipkart.com/input_Trending_q'))

// Save the text of the element with the specified ID into the local variable 'Actual Result' after removing double quotes
String ActualResult = WebUI.getText(findTestObject('FlipKart/Home Page Flipkart.com/span_grocery')).replace('"', '')

// Verify that the text in 'Actual Result' matches the expected result stored in the local variable 'Result'
WebUI.verifyEqual(ActualResult, Result)

// Close the browser
WebUI.closeBrowser()
