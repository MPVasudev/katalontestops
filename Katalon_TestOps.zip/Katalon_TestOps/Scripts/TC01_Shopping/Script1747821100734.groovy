import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/**
 1. Open brower and navigate to GlobalVariable.AURL
 2. Enter the serach text with the variable 'Keyword' at ID 'Object Repository/Amazon/Home Page Amazon.in/input_Search Amazon.in_field-keywords'
 3. Click on the search button with ID 'Object Repository/Amazon/Home Page Amazon.in/input_Search Amazon.in_nav-search-submit-button'
 4. Save value of the element text present with ID 'Object Repository/Amazon/SearchResult_Amazon.in/span_shoes' after removing the double quotes from string
 5. Verify the element text with the local variable 'Actual Result' same as the variable Result
 6. Close the browser
 **/
// Open browser and navigate to the specified URL
WebUI.openBrowser('')

// Navigate to the URL stored in GlobalVariable.AURL
WebUI.navigateToUrl(GlobalVariable.AURL)

// Enter the search text using the variable 'Keyword' in the search input field
WebUI.setText(findTestObject('Amazon/Home Page Amazon.in/input_Search Amazon.in_field-keywords'), Keyword)

// Click on the search button to initiate the search
WebUI.click(findTestObject('Amazon/Home Page Amazon.in/input_Search Amazon.in_nav-search-submit-button'))

// Save the text of the element with ID 'Amazon/Page_SearchResults/span_mobile' into a local variable 'Actual Result' after removing double quotes
String ActualResult = WebUI.getText(findTestObject('Object Repository/Amazon/SearchResult_Amazon.in/span_shoes')).replace('"', '')

// Verify that the text of the element matches the expected result stored in the variable 'Result'
WebUI.verifyEqual(ActualResult, Result)

// Close the browser
WebUI.closeBrowser()

